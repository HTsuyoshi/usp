'''
Esqueleto para o EP1 de Cripto 2021
Prof. Routo Terada
Monitor: Thales Paiva


Este arquivo é dividido em 4 partes:
    Parte 0: Protótipo das funções de aritmética modular
    Parte 1: Protótipo das funções de operações em curvas elípticas.
             Estas funções têm prefixo EC, de elliptic curves.
    Parte 2: Protótipo das funções de assinatura.
             Estas funções têm prefixo MV, de Menezes-Vanstone.
    Parte 3: As funções que efetivamente mostram o que foi pedido no EP.
'''

import random


######################### Funções de aritmética modular ###########################################

def extended_euclid(a: int, b: int):
    '''
    Implementa algoritmo de Euclides estendido.

    Entrada:
        a: inteiro
        b: inteiro
    Saída:
        (s, t, gcd), inteiros tais que
            s*a + t*b = gcd
    '''

    # Define valores iniciais
    old_s, s = 1, 0
    old_t, t = 0, 1

    # Simula o egcd enquanto b não for 0
    while b:
        q = a//b
        s, old_s = old_s - q*s, s
        t, old_t = old_t - q*t, t
        a, b = b, a % b

    # Retorna s, t e gcd(a,b)
    return old_s, old_t, a


def inverse_mod(a, m):
    '''
    Calcula a inversa de a módulo m usando o algoritmo de Euclides estendido.

    Entrada:
        a: inteiro
        m: inteiro
    Saída:
        a^(-1) mod m, caso exista, ou seja mdc(a, m) == 1

        Caso não exista, levanta ValueError.
    '''
    s, t, gcd = extended_euclid(a, m)

    if (gcd != 1):
        raise ValueError('mdc(a, modulo) deve ser 1 para haver inversa de a mod m')

    # Garante que o resultado está correto antes de devolvê-lo, ou joga um AssertionError
    assert(a * s % m == 1)

    return s

########################## Fim das funções de aritmética modular ##################################


##################### Funções e definições relacionadas às curvas elípticas #######################
# Supomos que as curvas elípticas são dadas na forma
#   y^2 = x^3 + A*x + B modulo M
#
# Dessa forma, essa curva geral é representada pelo trio (A, B, M)
#

# EXEMPLO:
#   A curva curva y^2 = x^3 + (-6)*x + 1 modulo 5381 é representada pelos seguintes coeficientes:
#   ec_coefficients = (-6, 1, 5381)

# O ponto no infinito, que pertence a todas as curvas elípticas, e
# é o elemento neutro da adição.
EC_POINT_AT_INFINITY = (None, None)


def EC_is_in_curve(ec_coefficients: tuple, point: tuple):
    '''
    Entrada:
        ec_coefficients: (A, B, M) coeficientes da curva elíptica C
            y^2 = x^3 + A*x + B modulo M
        point: (x, y) onde x e y são inteiros
    Saída:
        True se (x, y) pertence à curva C, False caso contrário.
    '''

    A, B, M = ec_coefficients
    x, y = point

    # LEMBRETE: O ponto no infinito sempre está na curva
    if point == EC_POINT_AT_INFINITY:
        return True

    # Verificar se a igualdade y^2 = x^3 + A*x + B modulo M está correta
    if ((y ** 2) % M) == (((x ** 3) + (A*x) + B) % M):
        return True

    return False

def EC_invert_point(ec_coefficients: tuple, point: tuple):
    '''
    Entrada:
        ec_coefficients: (A, B, M) coeficientes da curva elíptica C
            y^2 = x^3 + A*x + B modulo M
        point: (x, y)
    Saída:
        (x, -y): o ponto oposto a point: CUIDADO COM O módulo
    '''

    A, B, M = ec_coefficients

    # Inverte o ponto y módulo M
    return (point[0], (-point[1]) % M)


def EC_add_points(ec_coefficients: tuple, point1: tuple, point2: tuple):
    '''
    Entrada:
        ec_coefficients: (A, B, M) coeficientes da curva elíptica C
            y^2 = x^3 + A*x + B modulo M
        point1: (x1, y1) onde x1 e y1 são inteiros, um ponto de C
        point2: (x2, y2) onde x2 e y2 são inteiros, outro ponto de C

    Saída: Ponto (x, y) pertence à curva C, dado pela soma dos pontos point1
        e point2 segundo a expressão de soma de pontos.
    '''

    # Para lembrar das operações sobre pontos de curvas elípticas, veja o link abaixo:
    # https://en.wikipedia.org/wiki/Elliptic_curve_point_multiplication#Point_operations

    # IMPORTANTE: Cuidado com os casos que você terá de tratar separadamente:
    #   * Caso sejam pontos opostos
    #   * Caso sejam pontos iguais
    #   * Caso não sejam nem opostos nem iguais
    #
    # Cada caso usa uma expressão diferente para o resultado.

    A, B, M = ec_coefficients

    x1, y1 = point1
    x2, y2 = point2

    # Caso point1 seja esteja no infinito O + point2 = point2
    if point1 == EC_POINT_AT_INFINITY:
        return point2

    # Caso point2 seja esteja no infinito point1 + O = point1
    if point2 == EC_POINT_AT_INFINITY:
        return point1

    # Caso sejam pontos opostos retorna o ponto no infinito
    if point1 == EC_invert_point(ec_coefficients, point2):
        return EC_POINT_AT_INFINITY

    # Caso sejam pontos iguais define $tan = \frac{3x_1^2 + a}{2y_1}$
    if x1 == x2 and y1 == y2:
        tan = ((3 * (x1 ** 2)) + A) * inverse_mod(2 * y1, M)
    else:
    # Caso sejam pontos diferentes define $tan = \frac{y_2 - y_1}{x_2 - x_1}$
        tan = (y2 - y1) * inverse_mod(x2 - x1, M)

    # Calcula o valor dos pontos x e y
    x = ((tan ** 2) - x1 - x2)
    y = ((tan * (x1 - x)) - y1)

    # Devolve o valor dos pontos x e y modulo M
    return (x%M, y%M)

def EC_scalar_multiplication(ec_coefficients: tuple, scalar: int, point: tuple):

    # Você pode usar a função double-and-add, que é análoga à função square-and-multiply
    # para a exponenciação modular.

    # Em pseudocódigo, essa operação é a seguinteL
    #
    # bits = representação binária de scalar (bits mais significativos primeiro)
    # result_point = EC_POINT_AT_INFINITY
    #
    # for bit in bits:
    #     result_point = result_point + result_point (soma de pontos de curva elíptica)
    #     if bit == 1:
    #         result_point = result_point + point
    #
    # return point

    bits = []
    t = 1

    # Itera por todos os bits de scalar para criar um array de bits
    while t <= scalar:
        if t & scalar:
            bits.insert(0,1)
        else:
            bits.insert(0,0)
        t *= 2

    result_point = EC_POINT_AT_INFINITY

    # Itera o array de bits para fazer a exponenciação modular
    for bit in bits:
        result_point = EC_add_points(ec_coefficients, result_point, result_point)
        if bit == 1:
            result_point = EC_add_points(ec_coefficients, result_point, point)

    return result_point

################ Fim das Funções e definições relacionadas às curvas elípticas ####################


################################### Funções de assinatura #########################################

# Todas as funções abaixo usam a curva MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS para gerar chaves,
# assinar e verificar assinaturas.


# Para depurar seu programa, pode ser interessante usar uma curva elíptica num corpo menor.
# Para isso, configure a flag USE_DEBUG_ELLIPTIC_CURVE = True.
# Não esqueça de configurar a flag para USE_DEBUG_ELLIPTIC_CURVE = False depois.

USE_DEBUG_ELLIPTIC_CURVE = False

if USE_DEBUG_ELLIPTIC_CURVE:

    # Coeficientes da curva y^2 = x^3 + (-6)*x + 1 modulo 5381
    # Esta curva deve ser usada para assinar.
    MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS = (-6, 1, 5381)

    # PONTO P que é um parâmetro público do esquema
    MV_POINT_P = (9, 26)

    # Ordem do ponto P (isto é, MV_POINT_P_ORDER * P == EC_POINT_AT_INFINITY):
    MV_POINT_P_ORDER = 919


else:

    # Coeficientes da curva y^2 = x^3 + 7*x modulo 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f
    # Esta curva deve ser usada para assinar.
    MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS = (
        0,  # A
        7,  # B
        0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f  # MODULO
    )

    # PONTO P que é um parâmetro público do esquema
    MV_POINT_P = (
        0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798,
        0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8
    )

    # Ordem do ponto P (isto é, MV_POINT_P_ORDER * P == EC_POINT_AT_INFINITY):
    MV_POINT_P_ORDER =  0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141


def MV_keygen():
    '''
    Gera o par de chaves privada e pública.
    Saída:
        s: um inteiro correspondente à chave secreta
        Q: um ponto na curva elíptica correspondente à chave pública Q = sP.
    '''
    A, B, q = MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS
    n = MV_POINT_P_ORDER
    s = random.randrange(1, n)

    Q = EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, s, MV_POINT_P)

    return s, Q


def MV_sign(secret_key: int, hash_x: int):
    '''
    Assina hash de mensagem usando a chave secret_key do esquema Menezes-Vanstone.

    Entrada:
        secret_key: a chave secreta s
        hash_x: int, um inteiro entre 1 e n correspondente ao hash de uma mensagem
    Saída:
        (r, z): a assinatura sobre o hash_x
    '''
    n = MV_POINT_P_ORDER
    z, r = 0, 0

    # Caso z mod n seja igual a zero segue os passos da assinatura
    while z == 0:
        # Escolhe um inteiro K de {1,...,n}
        k = random.randrange(1, n + 1)

        # Calcula a multiplicação escalar de k com P
        r, t = EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, k, MV_POINT_P)

        # Para evitar erros caso r esteja no ifinito
        if r == None:
            continue

        # Calcula $z = k^{-1}(x + sr)$
        z = (inverse_mod(k, n) * (hash_x + secret_key * r )) % n
    return (r, z)



def MV_verify(public_key: tuple, signature: tuple, hash_x: int):
    '''
    Verifica assinatura segundo algoritmo de Menezes-Vanstone

    Entrada:
        public_key: Q chave pública de quem assinou a mensagem x
        signature: (r, z) a (potencial) assinatura de uma mensagem x
        hash_x: o hash da mensagem que foi assinada
    Saída:
        True se assinatura for válida, False caso contrário
    '''
    r, z = signature
    n = MV_POINT_P_ORDER
    Q = public_key
    P = MV_POINT_P

    # Recusa a assinatura caso não esteja no intervalo $1 \leq r,z \leq n-1$
    if (r < 1 or r > (n - 1)) or (z < 1 or z > (n - 1)):
        return False

    # Calcula $u_1 = z^{-1}x \mod n$
    u1 = (inverse_mod(z, n) * hash_x) % n

    # Calcula $u_2 = z^{-1}r \mod n$
    u2 = (inverse_mod(z, n) * r) % n

    # Calcula $P \times u_1$
    u1P = EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, u1, P)

    # Calcula $Q \times u_2$
    u2Q = EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, u2, Q)

    # Calcula $P \times u_1 + Q \times u_2 $
    x0, y0 = EC_add_points(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, u1P, u2Q)

    # retorna true se a assinatura for verdadeira
    if x0 == r:
        return True

    return False


def EC_run_tests():
    '''
    Esta é uma função para fazer alguns testes das suas implementações.
    Os testes são bem simples e vocês devem fazer outros.
    '''

    assert(EC_is_in_curve(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, EC_POINT_AT_INFINITY))

    P = MV_POINT_P
    assert(EC_is_in_curve(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, P))

    cummP = EC_POINT_AT_INFINITY
    points = []
    for i in range(1, 300):
        cummP = EC_add_points(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, P, cummP)

        scalar_multP = EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, i, P)
        #print(i, cummP, 'should be equal to', scalar_multP)

        assert(cummP == EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, i, P))
        assert(EC_is_in_curve(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, cummP))

        points.append(cummP)

    assert(not all([p == EC_POINT_AT_INFINITY for p in points]))

    print('Completed EC_run_tests()')

def MV_run_tests():
    '''
    Verifica que os parâmetros estão sãos:
        * Testa se o ponto MV_POINT_P não é o ponto no infinito
        * Testa se o ponto MV_POINT_P está na curva MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS
        * Testa se MV_POINT_P_ORDER * MV_POINT_P == EC_POINT_AT_INFINITY
    '''
    assert(MV_POINT_P != EC_POINT_AT_INFINITY)
    assert(EC_is_in_curve(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, MV_POINT_P))
    assert(EC_scalar_multiplication(MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS,
                                    MV_POINT_P_ORDER,
                                    MV_POINT_P) == EC_POINT_AT_INFINITY)

    # Verifica se a assinatura e verificação estão funcionando direito
    s, Q = MV_keygen()
    n = MV_POINT_P_ORDER
    x = random.randrange(n)
    signature = MV_sign(s, x)
    assert(MV_verify(Q, signature, x) == True)
    assert(MV_verify(Q, signature, x + 1) == False)
    assert(MV_verify(Q, signature, x - 1) == False)
    assert(MV_verify(Q, signature, x*n) == False)

    print('Completed MV_run_tests()')


def run_exercises():

    #    O ponto
    #   \begin{align*}
    #     Z = (
    #       & \texttt{0x714f956d8365148f9372ff1e69cf550b279381d6a837e87e5dcd38cfa1c56727},\\
    #       & \texttt{c403a250a26946f672517c118ed4f61b6c407d3407b0175437d1fba7a945d3e1})
    #   \end{align*}
    #   pertence à curva?

    Z = (0x714f956d8365148f9372ff1e69cf550b279381d6a837e87e5dcd38cfa1c56727,
         0xc403a250a26946f672517c118ed4f61b6c407d3407b0175437d1fba7a945d3e1)
    Z_is_in_curve = EC_is_in_curve(ec_coefficients=MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, point=Z)
    print(f'Q1: {Z_is_in_curve=}')

    # \item O ponto
    #   \begin{align*}
    #     Y = (
    #       & \texttt{0x76e64113f677cf0e10a2570d599968d31544e179b760432952c02a4417bdde39},\\
    #       & \texttt{0xc90ddf8dee4e95cf577066d70681f0d35e2a33d2b56d2032b4b1752d1901ac01})
    #   \end{align*}
    #   pertence à curva?

    Y = (0x76e64113f677cf0e10a2570d599968d31544e179b760432952c02a4417bdde39,
        0xc90ddf8dee4e95cf577066d70681f0d35e2a33d2b56d2032b4b1752d1901ac01)
    Y_is_in_curve = EC_is_in_curve(ec_coefficients=MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, point=Y)
    print(f'Q2: {Y_is_in_curve=}')

    # \item O ponto
    #   \begin{align*}
    #     X = (
    #       & \texttt{0x6cbc4847a842d45d0d031f0b933cfcb8488884685da384bc6c7ea175bd5dd1f0},\\
    #       & \texttt{0xc3d779d0048e8d4192864ae7226e9e6007a18bd8643e3d4f6f75b8a32ba6bc4c})
    #   \end{align*}
    #   pertence à curva?

    X = (0x6cbc4847a842d45d0d031f0b933cfcb8488884685da384bc6c7ea175bd5dd1f0,
        0xc3d779d0048e8d4192864ae7226e9e6007a18bd8643e3d4f6f75b8a32ba6bc4c)
    X_is_in_curve = EC_is_in_curve(ec_coefficients=MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, point=X)
    print(f'Q3: {X_is_in_curve=}')

    # \item Calcule o ponto $Z + Y$.

    Z_plus_y = EC_add_points(ec_coefficients=MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, point1=Z, point2=Y)
    print(f'Q4: {Z_plus_y=}')

    # \item Calcule o ponto $2^{100}Z$.
    multiplication = EC_scalar_multiplication(ec_coefficients=MV_ELLIPTIC_CURVE_A_B_COEFFICIENTS, scalar=2**100, point=Z)
    print(f'Q5: Z * 2^100 = {multiplication}')

    # \item Gere um par de chaves privada e pública (s, Q) e mostre na saída padrão.
    #       Estes valores serão usados nos próximos exercícios.
    s, Q = MV_keygen()
    print(f'Q6: Private Key {s=}, Public Key {Q=}')

    # \item Calcule a assinatura $(r, z)$ de
    #   $x = \texttt{0xd221c4371788e41c91a4be95c9cac7a7ea7a593f405b4213a5d903a457dbfa8}$
    #   usando a chave secreta $s$.
    x = 0xd221c4371788e41c91a4be95c9cac7a7ea7a593f405b4213a5d903a457dbfa8
    r, z = MV_sign(secret_key=s,hash_x=x)
    print(f'Q7: Sign {r=}, {z=}')

    # \item Verifique se assinatura $(r, z)$ é válida para $x$ usando
    #   usando a chave pública $Q$.
    x_valid_for_sign = MV_verify(public_key=Q, signature=(r,z), hash_x=x)
    print(f'Q8: {x_valid_for_sign=}')

    # \item Construa $x' = x \oplus 1$, onde $\oplus$ representa a operação XOR.
    #   Assim, $x'$ igual a $x$ com seu último bit alterado. Mostre $x'$ na saída
    #   padrão.
    new_x = x ^ 1
    print(f'Q9: {new_x=}')

    # \item Verifique se a assinatura $(r, z)$ de $x$ vale como assinatura de
    # $x'$ e mostre-a na saída padrão.
    new_x_valid_for_sign= MV_verify(public_key=Q, signature=(r,z), hash_x=new_x)
    print(f'Q10: {new_x_valid_for_sign=}')

    # \item Calcule a assinatura $(r', z')$ de $x'$ e mostre-a na saída padrão.
    new_r, new_z= MV_sign(s, new_x)
    print(f'Q11: New sign {new_r=} {new_z=}')

    # \item Verifique se a assinatura $(r', z')$ de $x'$ vale como assinatura de
    # $x$ e mostre-a na saída padrão.
    old_x_is_valid_for_new_sign = MV_verify(public_key=Q, signature=(new_r, new_z), hash_x=x)
    print(f'Q12: {old_x_is_valid_for_new_sign=}')

    # \item Qual a distância de Hamming entre $(r, z)$ e $(r', z')$? Note
    #   que você deve somar distâncias entre os blocos correspondentes, isto é,
    #   o resultado é dado por $\text{dist}(r, r') +  \text{dist}(z, z')$.
    def distancia_de_hamming(n1, n2) -> int:
        if n1 == None:
            n1 = 0

        if n2 == None:
            n2 = 0

        diff, nbits = n1 ^ n2, 0
        while diff != 0:
            if 1 & diff:
                nbits += 1
            diff = diff >> 1
        return nbits

    r_dist = distancia_de_hamming(r, new_r)
    z_dist = distancia_de_hamming(z, new_z)
    distancia_total_de_hamming = r_dist + z_dist

    print(f'Q13: {distancia_total_de_hamming=}')

if __name__ == '__main__':
    EC_run_tests()
    MV_run_tests()
    run_exercises()
