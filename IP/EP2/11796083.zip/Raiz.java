/*********************************************************************/
/**   ACH2001 - Introducao a  Programacao                            **/
/**   EACH-USP - Primeiro Semestre de 2020                          **/
/**   <02> - <Luciano Antonio Digiampietri>                                 **/
/**                                                                 **/
/**   Segundo Exercicio-Programa                                    **/
/**                                                                 **/
/**   <Henrique Tsuyoshi Yara>                   <11796083>          **/
/**                                                                 **/
/**   <26/04/2020>                                             **/
/*********************************************************************/

/*
	Calculo para raiz quadrada
*/
public class Raiz {

	static double raizQuadrada(double a, double epsilon) {
		// inicializa��o da vari�vel b que ser� usada no else mais pra frente
		double b= 0;
		// caso o a seja menor que zero ou epsilon menor que 0 ou epsilon maior que 1
		if(a<0 || epsilon<=0 || epsilon>=1) {
			return(-1);
		}
		// caso o a seja igual a zero
		if(a == 0) {
			return(0);
		}
		// caso n�o seja nenhum dos casos anteriores ir� rodar o m�todo de newton
		else {
			for(double AtualValor = (a/2.0), AntigoValor = 0.0, modulo = 1.0; modulo > epsilon; AtualValor = (1.0/2.0)*(AtualValor+(a/AtualValor))) {
				// modulo � a diferen�a do elemento atual(xi) com o �ltimo elemento(xi-1)
				modulo = AtualValor - AntigoValor;
				//o ultimo valor � atualizado depois do m�dulo para que a conta seja feita com o atual valor e o �ltimo valor
				AntigoValor = AtualValor;
				//o atual valor � armazenado fora do for para ser usado depois no return
				b = AtualValor;
				//caso o m�dulo d� negativo ele ir� inverter o valor
				if(modulo < 0) modulo = - modulo;
			}
			return(b);
		}
	}

	/*
		Apenas para seus testes. ISSO SERA IGNORADO NA CORRECAO
	*/
	public static void main(String[] args) {
		// escreva seu codigo (para testes) aqui

		// Exemplo de teste:
		double valor = 63;
		double precisao = 0.001;
		System.out.println("Raiz de : "+valor+" = "+raizQuadrada(valor, precisao));
	}
}