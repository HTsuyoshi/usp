/*********************************************************************/
/**   ACH2001 - Introdução �  Programação                            **/
/**   EACH-USP - Primeiro Semestre de 2020                          **/
/**   <02> - <Luciano Antonio Digiampietri>                                 **/
/**                                                                 **/
/**   Primeiro Exercício-Programa                                   **/
/**                                                                 **/
/**   <Henrique Tsuyoshi Yara>                   <11796083>          **/
/**                                                                 **/
/**   <30/03/2020>                                             **/
/*********************************************************************/

/*
	Caixa eletrônico das Ilhas Weblands, com estoque ilimitado de cédulas
	de B$50,00, B$10,00, B$5,00 e B$1,00.
*/
public class CaixaEletronico {
	// Número de cédulas de B$50,00
	static int n50;

	// Número de cédulas de B$10,00
	static int n10;

	// Número de cédulas de B$5,00
	static int n5;

	// Número de cédulas de B$1,00
	static int n1;


	/*
		Determina a quantidade de cada nota necessária para totalizar
		um determinado valor de retirada, de modo a minimizar a quantidade
		de cédulas entregues.

		Abastece as variáveis globais n50,n10, n5 e n1 com seu respectivo
		número de cédulas.

		Parâmetro:
			valor - O valor a ser retirado
	*/

	static void fazRetirada(int valor) {
		if(valor >= 0) {
		  //vai dividir o valor para descobrir a quantidade de notas de 50
			n50 = valor/50;
			  //coloca o resto da divisao por 50 valor em uma variavel inteira
				int restoDe50 = valor%50;
			//vai divir o resto da divisao de 50 para saber o numero de notas de 10
			n10 = restoDe50/10;
			  //coloca o resto da divisao por 10 em uma variavel inteira
				int restoDe10 = restoDe50%10;
			//vai dividir o resto da divisao de 10 para saber o numero de notas de 5
			n5 = restoDe10/5;
			  //coloca o resto da divisao por 5 em uma variavel inteira
				int restoDe5 = restoDe10%5;
		  //coloca o resto da divisao de 5 em uma variavel
			n1 = restoDe5/1;
		}
		else {
			//para dar tudo -1 nos n1,n5,10,50
			n50 = -1;
			n10 = -1;
			n5 = -1;
			n1 = -1;
		}
	}

	/*
		Apenas para seus testes. ISSO SERA IGNORADO NA CORREÇÃO
	*/
	public static void main(String[] args) {
		// escreva seu código (para testes) aqui

		// Exemplo de teste:
		fazRetirada(28);
		System.out.println("Notas de 50: "+n50);
		System.out.println("Notas de 10: "+n10);
		System.out.println("Notas de 5:  "+n5);
		System.out.println("Notas de 1:  "+n1);
	}
}
