/*********************************************************************/
/**   ACH2001 - Introdu��o � Programa��o                            **/
/**   EACH-USP - Primeiro Semestre de 2020                          **/
/**   <22> - <Luciano Antonio Digiampietri>                                 **/
/**                                                                 **/
/**   Terceiro Exerc�cio-Programa                                   **/
/**                                                                 **/
/**   <Henrique Tsuyoshi Yara>                   <11796083>          **/
/**                                                                 **/
/**   <09/05/2020>                                             **/
/*********************************************************************/

/*
Jogo da Velha - programa para verificar o status de um jogo.

Lista de Status calculado:
0 - Jogo n�o iniciado: o tabuleiro est� 'vazio', isto � sem pe�as X e O;
1 - Jogo encerrado1: o primeiro jogador (que usa as pe�as X) � o ganhador;
2 - Jogo encerrado2: o segundo jogador (que usa as pe�as O) � o ganhador;
3 - Jogo encerrado3: empate - todas as casas do tabuleiro est�o preenchidas com X e O, mas nenhum dos jogadores ganhou;
4 - Jogo j� iniciado e em andamento: nenhuma das alternativas anteriores.	
*/


public class JogoDaVelha {
	static final char pecaX = 'X';
	static final char pecaY = 'O';
	static final char espacoVazio = ' ';

	/*
	 * Determina o status de uma partida de Jogo da Valha
	 * 
	 * Entrada: tabuleiro - matriz 3x3 de caracteres representando uma partida
	 * valida de Jogo da Velha
	 * 
	 * Sa�da: um inteiro contendo o status da partida (valores v�lidos de zero a
	 * quatro)
	 */
	static int verificaStatus(char[][] tabuleiro) {
		int status = -1;

		// vari�veis que ser�o utilizadas depois
		int i = 0;
		int j = 0;

		// caso o tabuleiro esteja vazio (0)
		while (tabuleiro[i][j] == espacoVazio) {
			j++;
			if (j == 2 && i < 2) {
				j = 0;
				i++;
			}
			if (i == 2 && j == 3) {
				status = 0;
				return status;
			}
		}

		// caso alguem tenha vencido o jogo em alguma das diagonais, coluna do meio ou linha do meio, retorna(1,2)
		if (tabuleiro[1][1] != espacoVazio
				&& ((tabuleiro[0][0] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][2])
						|| (tabuleiro[0][2] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][0])
						|| (tabuleiro[0][1] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][1])
						|| (tabuleiro[1][0] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[1][2]))) {
			switch (tabuleiro[1][1]) {
			case pecaX:
				status = 1;
				return status;
			case pecaY:
				status = 2;
				return status;
			}
		}

		// caso alguem tenha vencido usando o canto tabuleiro[0][0], retorna(1 ou 2)
		if (tabuleiro[0][0] != espacoVazio
				&& ((tabuleiro[0][0] == tabuleiro[2][0] && tabuleiro[0][0] == tabuleiro[1][0]) || 
				    (tabuleiro[0][0] == tabuleiro[0][2] && tabuleiro[0][0] == tabuleiro[0][1]))) {
			switch (tabuleiro[0][0]) {
			case pecaX:
				status = 1;
				return status;
			case pecaY:
				status = 2;
				return status;
			}
		}

		// caso alguem tenha vencido usando o canto do tabuleiro[2][2], retorna(1 ou 2)
		if (tabuleiro[2][2] != espacoVazio
				&& ((tabuleiro[2][2] == tabuleiro[2][1] && tabuleiro[2][2] == tabuleiro[2][0]) || 
				    (tabuleiro[2][2] == tabuleiro[0][2] && tabuleiro[2][2] == tabuleiro[1][2]))) {
			switch (tabuleiro[2][2]) {
			case pecaX:
				status = 1;
				return status;
			case pecaY:
				status = 2;
				return status;
			}
		}

		// resetar as vari�veis para que possam ser utilizadas novamente
		i = 0;
		j = 0;

		// caso o tabuleiro esteja todo ocupado (3)
		while (tabuleiro[i][j] != espacoVazio) {
			j++;
			if (j == 2 && i < 2) {
				j = 0;
				i++;
			}
			if (i == 2 && j == 3) {
				status = 3;
				return status;
			}
		}
		
		//caso esteja em andamento(4)
		status = 4;
		return status;
	}

	/*
	 * Apenas para seus testes. ISSO SER� IGNORADO NA CORRE��O
	 */
	public static void main(String[] args) {
		// escreva seu c�digo (para testes) aqui

		char[][] tab0 = { { ' ', ' ', ' ' }, { ' ', ' ', ' ' }, { ' ', ' ', ' ' } };
		char[][] tab1 = { { 'X', 'X', 'X' }, { 'O', 'O', ' ' }, { ' ', ' ', ' ' } };
		char[][] tab2 = { { 'O', 'X', 'X' }, { 'X', 'O', 'O' }, { ' ', ' ', 'O' } };
		char[][] tab3 = { { 'O', 'X', 'X' }, { 'X', 'O', 'O' }, { 'O', 'X', 'X' } };
		char[][] tab4 = { { ' ', ' ', ' ' }, { 'X', 'O', 'X' }, { ' ', ' ', ' ' } };

		System.out.println("Status calculado: " + verificaStatus(tab0));
		System.out.println("Status esperado para o tabuleiro0: 0\n");

		System.out.println("Status calculado: " + verificaStatus(tab1));
		System.out.println("Status esperado para o tabuleiro1: 1\n");

		System.out.println("Status calculado: " + verificaStatus(tab2));
		System.out.println("Status esperado para o tabuleiro2: 2\n");

		System.out.println("Status calculado: " + verificaStatus(tab3));
		System.out.println("Status esperado para o tabuleiro3: 3\n");

		System.out.println("Status calculado: " + verificaStatus(tab4));
		System.out.println("Status esperado para o tabuleiro4: 4\n");

	}
}