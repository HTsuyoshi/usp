
public class ClienteEspecial extends Cliente{
	static final int dividaMaxima = 50000;
	static final String tipo = "CE";
	
	/* Construtor da Classe ClienteEspecial
	 * Este construtor invoca o construtor da classe Cliente.
	 */
	ClienteEspecial(String nome, int cpf, int valor){
		super(nome, cpf, valor);
	}
	
	/* Metodo que retorna o valor do atributo tipo do objeto atual */
	String retornaTipo() {
		return tipo;
	}
	
	//esse metodo precisa ser sobrescrito pois o valor divida maxima e diferente no
	//cliente especial
	public boolean obterEmprestimo(int valor) {
		
		//em caso o valor ser menor ou igual a zero retornar false
		if(valor <= 0) return false;
		
		//caso o valor mais o valor da divida do cliente sejam maior que a divida maxima retornar false
		if(valor + this.getValorDaDivida() > ClienteEspecial.dividaMaxima) return false;
			
		else {
		//incrementa o atributo valorDaDivida em valor
			this.setValorDaDivida(this.getValorDaDivida() + valor);
			this.setValorContaCorrente(this.getValorContaCorrente() + valor);
			return true;
		}

	}
	
}
